// document id
var doc_id = "kag3doc";
